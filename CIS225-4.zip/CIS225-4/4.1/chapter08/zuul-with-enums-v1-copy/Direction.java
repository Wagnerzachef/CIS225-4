
/**
 * Enumeration class Direction - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Direction
{
    NORTH, SOUTH, EAST, WEST
}
