import java.util.ArrayList;
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Player
{
    // instance variables - replace the example below with your own
    private Room currentRoom;
    private String name;
    private ArrayList<Item> items;
    public static int maxWeight;
    private int inventoryWeight;

    /**
     * Constructor for objects of class Player
     */
    public Player(String name, Room startingRoom)
    {
        // initialise instance variables
        this.name = name;
        currentRoom = startingRoom;
        items = new ArrayList<>();
        maxWeight = 1500;
        inventoryWeight = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public ArrayList getItems()
    {
        return items;
    }
    public int getInventoryWeight()
    {
        return inventoryWeight;
    }
    
    public void takeItem(Item item)
    {
        items.add(item);
        inventoryWeight += item.getWeight();
    }
    public int getMaxWeight()
    {
        return maxWeight;
    }
    public void setMaxWeight(int maxWeight)
    {
        this.maxWeight = maxWeight;
    }
    
    public Item dropItem(String itemName)
    {
        Item item = null;
        for(Item i : items) {
            if(i.getName().equals(itemName)) {
                item = i;
                System.out.println(item.getName() + " dropped"); 
                inventoryWeight -= item.getWeight();
            }
        }
        items.remove(item);
        if(item == null) {
            System.out.println("You do not have that item.");
        }
        System.out.println("Inventory: ");
        for(Item i : items) {
            System.out.println(i.getItemInfo());
            System.out.println("Current capacity: " + (maxWeight - inventoryWeight));
        }
        return item;
    }
    public void getInventory()
    {
        System.out.println("Current inventory: " );
        for(Item i : items) {
            System.out.println(i.getItemInfo());
        }
    }
    public void eatCookie()
    {
        for(Item i : items) {
            if(i.getName().equals("Cookie")) {
                maxWeight += 2000;
                System.out.println("Cookie eaten.");
                System.out.println("New max weight: " + maxWeight);
            }
        }
    }
    public boolean hasBeamer()
    {
        boolean hasIt = false;
        for(Item i : items) {
            if(i.getName().equals("beamer")) {
                hasIt =true;
            }
        }
        return hasIt;
    }
    
    public void setCurrentRoom(Room currentRoom)
    {
        this.currentRoom = currentRoom;
    }
    
    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    public String getName()
    {
        return name;
    }
}
