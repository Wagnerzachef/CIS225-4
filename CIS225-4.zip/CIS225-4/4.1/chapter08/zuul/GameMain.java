
/**
 * Write a description of class GameMain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GameMain
{
    // instance variables - replace the example below with your own
    public static void main(String[] args)
    {
        Game game = new Game("help");
        game.play();
    }

    
}
