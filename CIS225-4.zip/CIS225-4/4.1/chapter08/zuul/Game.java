import java.util.Stack;
import java.util.Random;
import java.util.ArrayList;

/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Game 
{
    private Parser parser;
    private NPC talkingTo = null;
    private Room currentRoom;
    private Room previousRoom;
    private Stack<Room> roomPath;
    private Player player;
    private int counter;
    private static final int maxCount = 20;
    private Room chargedRoom;
    private boolean hasKey;
    private Room randomRoom;
    private Random rand;
    private ArrayList<NPC> characters;
    /**
     * Create the game and initialise its internal map.
     */
    public Game(String name) 
    {
        createRooms(name);
        parser = new Parser();
        hasKey = false;
        Random rand = new Random();
        
        
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms(String name)
    {
        Room hall, bedroom, leftHall, rightHall, entrance, exit, pit, tower, cellar, door;
      
        // create the rooms
        entrance = new Room("You awake inside of a entrance hall. The door leading out is locked.");
        leftHall = new Room("The left hall is filled with paintings with a door at the end.");
        rightHall = new Room("The right hall has two doors. The one on your left is labeled tower and the one ahead of you has it's label scratched out.");
        hall = new Room("A dark hall with no lights. The door slams shut behind you. Your only path is forward.");
        bedroom = new Room("A dark bedroom.");
        pit = new Room("The only thing in this room seems to be an endless pit. You feel like you should turn back.");
        tower = new Room("You enter the tower to find that the stairs up aare falling apart.");
        exit = new Room("You made it out of the weird house.");
        cellar = new Room("How did you get down there?");
        door = new Room("A door with a old key hole.");
        
        // initialise room exits
        entrance.addItem(1200, "A cookie you found on the floor", "Cookie");
        entrance.addItem(1500, "A teleportation device", "beamer");
        bedroom.addItem(200, "a old key", "key");
        entrance.setExit("north", hall);
        entrance.setExit("east", leftHall);
        entrance.setExit("west", rightHall);
        rightHall.setExit("south", entrance);
        rightHall.setExit("north", bedroom);
        rightHall.setExit("west", tower);
        leftHall.setExit("south", entrance);
        leftHall.setExit("north", pit);
        hall.setExit("north", exit);
        bedroom.setExit("south", rightHall);
        tower.setExit("south", rightHall);
        pit.setExit("south", leftHall);
        exit.setExit("south", hall);
        cellar.setExit("up", door);
        bedroom.setExit("down", door);
        door.setExit("up", bedroom);
        door.setExit("down",cellar);
        
        currentRoom = entrance;  // start game outside
        player = new Player(name, entrance);
        roomPath = new Stack<>();
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing " + player.getName() + ".  Good bye.");
    }

    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to the World of Zuul!");
        System.out.println("World of Zuul is a new, incredibly boring adventure game.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println(currentRoom.getLongDescription());
    }
    private void look()
    {
        System.out.println(player.getCurrentRoom().getLongDescription());
    }
    public void eat()
    {
        System.out.println("You have eaten everything in this room. I hope you are happy with yourself.");
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            printHelp();
        }
        else if (commandWord.equals("go")) {
            goRoom(command);
        }
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }
        else if (commandWord.equals("look")) {
            look();
        }
        
        else if(commandWord.equals("back")) {
            leaveRoom();
        }
        else if(commandWord.equals("take")) {
            take(command);
        }
        else if(commandWord.equals("drop")) {
            drop(command);
        }
        else if(commandWord.equals("items")) {
            player.getInventory();
        }
        else if(commandWord.equals("cookie")) {
            player.eatCookie();
        }
        else if(commandWord.equals("charge")) {
            charge();
        }
        else if(commandWord.equals("talk")) {
            talk(command);
        }
        else if(commandWord.equals("give")) {
            give(command);
        }
        moveCharacters();
        return wantToQuit;
    }
    public void leaveRoom()
    {
        if(roomPath.empty()) {
            System.out.println("You can not go back any further.");
        }
        else{
            player.setCurrentRoom(roomPath.pop());
            System.out.println(player.getCurrentRoom().getLongDescription());
        }
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around the house.");
        System.out.println();
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    /** 
     * Try to go in one direction. If there is an exit, enter
     * the new room, otherwise print an error message.
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("Go where?");
            return;
        }
        counter = 0;
        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = player.getCurrentRoom().getExit(direction);
        
        if (nextRoom == null) {
            System.out.println("There is no door!");
        }
        else {
            
            
            roomPath.push(currentRoom);
            previousRoom = currentRoom;
            currentRoom = nextRoom;
            if(currentRoom.equals("door")) {
                if(!hasKey) {
                    System.out.println("This door is locked. Find the key to unlock it.");
                    currentRoom = previousRoom;
                }
            }
            if(currentRoom.equals("tower")) {
                if(!hasKey) {
                   System.out.println("You found an old key!");
                   hasKey = true;
                }
            }
            
            System.out.println(currentRoom.getLongDescription());
            if(counter < maxCount) {
                counter++;
            }
            else{
                System.out.println("Times up!");
                
            }
        }
        
        
    }
    private void createCharacters() 
    {
        Item johnReward = new Item("cake", "Chocolate cake", 5);
        NPC john = new NPC("John", "Man without a hat.",
                "Give him a hat.", "hat", johnReward, player.getCurrentRoom());
        characters.add(john);
    }
    private void moveCharacters()
    {
        Random rand = new Random();
        Room current = null;
        for(NPC c : characters) {
            if (rand.nextDouble() > 0.5) {
                current = c.getCurrentRoom();
                String[] neighbors = current.getExitDirections();
                int r = rand.nextInt(neighbors.length);
                c.setCurrentRoom(current.getExit(neighbors[r]));
                current.removeCharacter(c);
            }
        }
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
    private void take(Command command) 
    {
        if(!command.hasSecondWord()) { 
            System.out.println("Take what?"); 
            return; 
        } 
        String itemName = command.getSecondWord(); 
        Item item = player.getCurrentRoom().getItem(itemName);
        int playerCapacity = Player.maxWeight;
        if(player.getInventoryWeight() + item.getWeight() <= playerCapacity) {
            player.takeItem(item); 
            System.out.println(item.getDescription() + " taken");
            player.getCurrentRoom().removeItem(item); 
        } 
        else { 
            System.out.println("The item load too heavy! Try dropping some items.");
        } 
        System.out.println("Current capacity: " + player.getInventoryWeight() + " g.");
    }
    private void drop(Command command) 
    {
        if(!command.hasSecondWord()) {
            System.out.println("Drop what?");
              return;
        }
        String itemName = command.getSecondWord();
        player.getCurrentRoom();
        player.dropItem(itemName); 
    }
    private void charge()
    {
        if(player.hasBeamer() == true) {
            chargedRoom = currentRoom;
            System.out.println("Portal set down in room.");
        }
        else {
            System.out.println("You need the beamer to perform that action.");
        }
    }
    private void fired()
    {
        if(player.hasBeamer() == true) {
            player.setCurrentRoom(chargedRoom);
            System.out.println("You have been teleported to the charged room.");
        }
        else {
            System.out.println("You need a beamer to use this command.");
        }
    }
    private void talk(Command command) 
    {
        if(!command.hasSecondWord()) {
            System.out.println("Talk to whom?");
            return;
        }
        String name = command.getSecondWord();
        NPC c = player.getCurrentRoom().getCharacter(name);
            
        talkingTo = c;
        if (talkingTo == null) {
            System.out.println("This character is not present in this room");
        } 
        else {
            System.out.println(c.talk());
        }
    }
    private void give(Command command)
    {
        if(!command.hasSecondWord()) {
            System.out.println("Give what?");
            return;
        }
        if (talkingTo == null) {
            System.out.println("You have to first talk to someone in order to give an item.");
        }
        else {
            Item item = talkingTo.getReward();
            String name = command.getSecondWord();
            if (name.equals(talkingTo.getItem())) {
                if (player.getInventoryWeight() + item.getWeight() <= player.getMaxWeight()) { 
                    player.dropItem(name);
                    player.takeItem(talkingTo.giveReward());
                    player.getCurrentRoom().removeCharacter(talkingTo);
                    talkingTo = null;
                } else {
                    System.out.println("Item too heavy! Try dropping some items.");
                }
            } else {
            System.out.println("Wrong item is given.");
            }
        }
    }
}
