import java.util.Random;
/**
 * Write a description of class NPC here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NPC
{
    private String name;
    private String description;
    private String quest;
    private String questItem;
    private Item reward;
    private Room currentRoom;
    
    public NPC(String name, String description, String quest, String questItem, Item reward, Room currentRoom) {
        this.name = name;
        this.description = description;
        this.questItem = questItem;
        this.quest = quest;
        this.reward = reward;
        setCurrentRoom(currentRoom);
    }
    public String getName()
    {
        return name;
    }
    public String getDesc()
    {
        return description;
    }
    public String getItem()
    {
        return questItem;
    }
    public String getQuest()
    {
        return quest;
    }
    public Item getReward()
    {
        return reward;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public void setDesc(String description)
    {
        this.description = description;
    }
    public void setItem(String questItem)
    {
        this.questItem = questItem;
    }
    public void setQuest(String name)
    {
        this.quest = quest;
    }
    public void setReward(Item reward)
    {
        this.reward = reward;
    }
    public String getCharacterInfo() 
    {
        return "name: " + name + "\ndescription: " + description;
    }
    
    public String talk()
    {
        return quest;
    }
    public Item giveReward() 
    {
        Item i = reward;
        reward = null;
        return i;
    }
    public Room getCurrentRoom()
    {
        return currentRoom;
    }
    
    public void setCurrentRoom(Room room)
    {
        currentRoom.addCharacter(this);
        currentRoom = room;
    }

}