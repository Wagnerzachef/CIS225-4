import java.util.HashMap;
import java.util.ArrayList;
import java.util.Set;
/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  The exits are labelled north, 
 * east, south, west.  For each direction, the room stores a reference
 * to the neighboring room, or null if there is no exit in that direction.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */
public class Room 
{
    public String description;
    public Room northExit;
    public Room southExit;
    public Room eastExit;
    public Room westExit;
    public Room upExit;
    public Room downExit;
    private HashMap<String, Room> exits;
    private ArrayList<NPC> characters;
    private ArrayList<Item> items;

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open court yard".
     * @param description The room's description.
     */
    public Room(String description) 
    {
        this.description = description;
        exits = new HashMap<>();
        items = new ArrayList<>();
        characters = new ArrayList<>();
    }
    
    public String getLongDescription()
    {
        return description + ".\n" + getExitString() + getItemsInfo() + getCharactersInfo();
    }
    public void addItem(int itemWeight, String itemDesc, String itemName)
    {
        items.add(new Item(itemName, itemDesc, itemWeight));
    }
    
    
    public String getItemsInfo()
    {
        String itemsInfo = " ";
        for(Item item : items) {
            itemsInfo += item.getItemInfo() + " ";
        }
        return itemsInfo;
    }
    public Item getItem(String itemName)
    {
        Item item = null;
        for(Item i : items){
            if(i.getName().equals(itemName)) {
                item = i;
            } 
        }
        if (item == null) { 
            System.out.println("There is no such item in this room.");
            return item;
        }

        return item;
    }
    public void removeItem(Item item)
    {
        items.remove(item);
    }

    /**
     * Define the exits of this room.  Every direction either leads
     * to another room or is null (no exit there).
     * @param north The north exit.
     * @param east The east east.
     * @param south The south exit.
     * @param west The west exit.
     */
    public void setExits(Room north, Room east, Room south, Room west, Room up, Room down, Room lock) 
    {
        if(north != null) {
            exits.put("north", north);
        }
        if(east != null) {
            exits.put("east", east);
        }
        if(south != null) {
            exits.put("south", south);
        }
        if(west != null) {
            exits.put("west", west);
        }
        if(up != null) {
            exits.put("up", up);
        }
        if(down != null) {
            exits.put("down", down);
        }
        if(lock != null) {
            exits.put("lock", lock);
        }
    }
    public Room getExit(String direction)
    {
        return exits.get(direction);
    }
    public void setExit(String direction, Room neighbor)
    {
        exits.put(direction, neighbor);
    }

    /**
     * @return The description of the room.
     */
    public String getDescription()
    {
        return description;
    }
    public String getExitString()
    {
        String returnString = "Exits:";
        Set<String> keys = exits.keySet();
        for(String exit : keys) {
            returnString += " " + exit;
        }
        returnString += ".\n";
        return returnString;
    }
    public void addCharacter(String name, String description, String quest, String questItem, Item reward)
        {
        addCharacter(new NPC(name, description, quest, questItem, reward, this));
    }
    public String[] getExitDirections()
    {
        return (String[]) exits.keySet().toArray();
    }
    
    public void addCharacter(NPC character)
    {
        characters.add(character);
    }    
    
    public void removeCharacter(NPC character) 
    {
        characters.remove(character);
    }
    private String getCharactersInfo() 
    {
        String s = "";
        for (NPC c : characters) {
            s += c.getCharacterInfo();
        }
        return s;
    }
    public NPC getCharacter(String name)
    {
        NPC character = null;
        for (NPC c : characters) {
            if (c.getName().equals(name)) {
                character = c;
                characters.remove(c);
                break;
            }
        }
        if (character == null) {
            System.out.println("There is no such character in this room.");
        }
        return character;
    }
}
