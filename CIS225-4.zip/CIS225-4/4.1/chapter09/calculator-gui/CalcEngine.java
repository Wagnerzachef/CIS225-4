/**
 * The main part of the calculator doing the calculations.
 * 
 * @author: (none yet)
 * @version 0.1 (incomplete)
 */
public class CalcEngine
{
    // Put instance variables here.
    private int displayValue;
    private char previousOperator;
    private int leftOperand;
    private boolean resetDisplayValue;

    public CalcEngine() 
    {
        displayValue = 0;
        previousOperator = ' ';
        leftOperand = 0;
        resetDisplayValue = false;
    }
    public int getDisplayValue() 
    {
        return displayValue;
    }
    public void numberPressed(int number) 
    {
        if(resetDisplayValue) {
            displayValue = 0; 
            displayValue = displayValue * 10 + number; 
            resetDisplayValue = false; 
        }
    }
    public void equals()
    { 
        if (previousOperator == '+') {
            displayValue = leftOperand + displayValue;
        } 
        else {
            displayValue = leftOperand - displayValue; 
        } 
        leftOperand = 0; 
        previousOperator = ' ';
    }
    public void plus() 
    {
        applyPreviousOperator();
        previousOperator = '+';
        resetDisplayValue = true;
    }
    public void minus() 
    {
        applyPreviousOperator();
        previousOperator = '-';
        resetDisplayValue = true;
    }
    private void applyPreviousOperator() 
    {
        if (previousOperator == '+') {
            leftOperand += displayValue;
        } else if (previousOperator == '-') {
            leftOperand -= displayValue;
        } else {
            leftOperand = displayValue;
        }
    }
    public void clear() 
    {
        displayValue = 0;
        previousOperator = ' ';
    }
    public String getTitle() 
    { 
        return "Texas Instruments";
    }
    public String getAuthor()
    {
        return "Mark";
    }
    public String getVersion()
    {
        return "1";
    }
}
