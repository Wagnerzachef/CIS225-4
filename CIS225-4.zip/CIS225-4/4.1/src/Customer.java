/**
 * class to make store customer name and id
 *
 * @author Zach Wagner
 * @version 1
 */
public class Customer
{
    // instance variables - replace the example below with your own
    private String customerID;
    private String customerFirstName;
    private String customerLastName;

    /**
     * Constructor for objects of class Customer
     */
    public Customer(String customerID, String customerFirstName, String customerLastName)
    {
        // initialise instance variables
        this.customerID = customerID;
        this.customerFirstName = customerFirstName;
        this.customerLastName = customerLastName;
    }

    /**
     * method to get customer id
     *
     * @return    customers id
     */
    public String getCustomerID()
    {
        return customerID;
    }
    /**
     * method to get customers first name
     *
     * @return customers first name
     */
    public String getCustomerFirstName()
    {
        return customerFirstName;
    }
    /**
     * method to get customers last name
     *
     * @return customers last name
     */
    public String getCustomerLastName()
    {
        return customerLastName;
    }
}

