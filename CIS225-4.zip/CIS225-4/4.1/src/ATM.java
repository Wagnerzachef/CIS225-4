import java.util.Scanner;
import java.util.ArrayList;
/**
 * Write a description of class ATM here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ATM
{
    // instance variables - replace the example below with your own
    private Bank bank;
    private ArrayList<String> log;


    /**
     * Constructor for objects of class ATM
     */
    public ATM(Bank bank)
    {
        // initialise instance variables
        this.bank = bank;
        log = new ArrayList<>();
    }
    public void startTransaction()
    {
        String cardNumber, selectedAccount = "", selectedAction;
        ArrayList<String> accountNumbers = new ArrayList<>();
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to the ATM, please enter your card number: ");
        cardNumber = scan.next();
        for(Card card : bank.getCards()) {
            if(card.getCardNumber().equals(cardNumber)) {
                if(validateUser(card)) {
                    accountNumbers = getCardAccountNumbers(card);
                    printCardAccountNumbers(card);
                    int userInput = -1;
                    while(userInput < 0 || userInput > accountNumbers.size() - 1) {
                        System.out.println("Please select an account to make an action with that account: ");
                        userInput = Integer.parseInt(scan.next());
                    }
                    selectedAccount = accountNumbers.get(userInput);
                    boolean complete = false;
                    while(!complete) {
                        System.out.println("Please select an action (deposit | withdraw | transfer | balance | end): ");
                        selectedAction = scan.next();
                        switch (selectedAction) {
                            case "deposit":
                                log.add(makeDeposit(selectedAccount));
                                System.out.println("Transaction Receipt: " + log.get(log.size() - 1));
                                break;

                            case "withdraw":
                                log.add(makeWithdraw(selectedAccount));
                                System.out.println("Transaction Receipt: " + log.get(log.size() - 1));
                                break;

                            case "balance":
                                checkBalance(selectedAccount);
                                break;

                            case "transfer":
                                System.out.println("Please enter the account you want to transfer from: ");
                                userInput = Integer.parseInt(scan.next());
                                String transferToAccount = accountNumbers.get(userInput);
                                log.add(transfer(selectedAccount, transferToAccount));
                                System.out.println("Transaction Receipt: " + log.get(log.size() - 1));


                            case "end":
                                complete = true;
                                break;

                            default:
                                System.out.println("That is not a valid selection.");
                                break;
                        }
                    }
                }
                else {
                    System.out.println("Too many failed attempts!");
                }
            }
            else {
                System.out.println("That is not a valid card!");
            }
        }
        System.out.println("Goodbye...");
    }
    /**
     * method to transfer money between accounts
     */
    public String transfer(String selectedAccount, String transferToAccount)
    {
        double transferAmount;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the amount you want to transfer: ");
        transferAmount = Double.parseDouble(scan.next());
        if(transferAmount != 0 && transferAmount % 4 == 0) {
            for(Account account : bank.getAccounts()) {
                if(account.getAccountNumber().equals(selectedAccount)) {
                    for(Account transferAccount : bank.getAccounts()) {
                        if(transferAccount.getAccountNumber().equals(transferToAccount)) {
                            transferAccount.addToBalance(transferAmount);
                            account.withdrawFromBalance(transferAmount);
                            return "Transfer OF $" + transferAmount + " FROM " + selectedAccount + " TO " + transferToAccount;
                        }
                        else {
                            return "TRANSFER FAILED";
                        }
                    }
                }
            }
            return "TRANSFER FAILED";
        }
        else {
            return "TRANSFER FAILED";
        }
    }
    /**
     * a method to check if the user has a valid pin
     *
     * @param  card to look at
     * @return true if the pin is correct
     */
    private boolean validateUser(Card card)
    {
        int counter = 0;
        String pin;
        Scanner scan = new Scanner(System.in);
        while(counter < 3) {
            System.out.println("\nPlease enter your pin: ");
            pin = scan.next();
            if(card.getPin().equals(pin)) {
                return true;
            }
            else {
                counter++;
            }
        }
        return false;
    }
    /**
     * a method to get the account numbers associated with the card
     *
     * @param  card to look at
     * @return the acconts on the card
     */
    private ArrayList<String> getCardAccountNumbers(Card card)
    {
        ArrayList<String> accountNumbers = new ArrayList<String>();
        for(String accountNumber : card.getAccountNumbers()) {
            for(Account account : bank.getAccounts()) {
                if(account.getAccountNumber().equals(accountNumber)) {
                    accountNumbers.add(accountNumber);
                }
            }
        }
        return accountNumbers;
    }
    /**
     * method to print out the accounts on the cards
     *
     * @param card the card the code will look at
     */
    private void printCardAccountNumbers(Card card)
    {
        int counter = 0;
        System.out.println("Accounts linked to this card: ");
        for(String accountNumber : card.getAccountNumbers()) {
            for(Account account : bank.getAccounts()) {
                if(account.getAccountNumber().equals(accountNumber)) {
                    System.out.println(counter + " - Account: " + accountNumber);
                    counter++;
                }
            }
        }
    }
    /**
     * method to deposit money into a bank account
     *
     * @param selectedAccount the account to deposit to
     */
    private String makeDeposit(String selectedAccount)
    {
        double depositAmount;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter deposit amount in a multiple of 20: ");
        depositAmount = Double.parseDouble(scan.next());
        if(depositAmount != 0 && depositAmount % 4 == 0)
        {
            for(Account account : bank.getAccounts())
            {
                if(account.getAccountNumber().equals(selectedAccount))
                {
                    account.addToBalance(depositAmount);
                    return "Deposit OF $" + depositAmount + " TO " + selectedAccount;
                }
            }
            return "FAILED TO DEPOSIT $" + depositAmount + " TO " + selectedAccount;
        }
        else
        {
            return "FAILED TO DEPOSIT $" + depositAmount + " TO " + selectedAccount;
        }
    }
    /**
     * method to withdraw money from a bank account
     *
     * @param selectedAccount the account to withdraw from
     */
    private String makeWithdraw(String selectedAccount)
    {
        double withdrawAmount;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the amount to withdraw in a multiple of 20: ");
        withdrawAmount = Double.parseDouble(scan.next());
        if(withdrawAmount > 0 && withdrawAmount % 4 == 0) {
            for(Account account : bank.getAccounts()) {
                if(account.getAccountNumber().equals(selectedAccount)) {
                    if(account.getBalance() >= withdrawAmount) {
                        account.withdrawFromBalance(withdrawAmount);
                        return "Withdraw OF $" + withdrawAmount + " FROM " + selectedAccount;
                    }
                    else {
                        return "FAILED TO WITHDRAW $" + withdrawAmount + " FROM " + selectedAccount + "(INSUFFICIENT FUNDS)";
                    }
                }
            }
            return "FAILED TO WITHDRAW $" + withdrawAmount + " FROM " + selectedAccount;
        }
        else {
            return "FAILED WITHDRAW OF $" + withdrawAmount + " FROM " + selectedAccount;
        }
    }
    /**
     * a method to check the balance of the selected account
     *
     * @param selectedAccount the account that will be checked
     */
    private void checkBalance(String selectedAccount)
    {
        for(Account account : bank.getAccounts())
        {
            if(account.getAccountNumber().equals(selectedAccount))
            {
                System.out.println("Account Balance: $" + account.getBalance());
            }
        }
    }
    public static void main(String[] args)
    {
        Bank bank = new Bank();
        ATM thing = new ATM(bank);
        thing.startTransaction();
    }
}
