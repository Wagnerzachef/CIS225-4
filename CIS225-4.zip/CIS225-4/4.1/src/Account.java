import java.util.ArrayList;
/**
 * A class to store account information
 *
 * @author Zach Wagner
 * @version 1
 */
public class Account
{
    // instance variables - replace the example below with your own
    private double balance;
    private String accountNumber;
    private ArrayList<Customer> accountHolders;
    /**
     * Constructor for objects of class Account
     */
    public Account(String accountNumber, ArrayList<Customer> accountHolders)
    {
        // initialise instance variables
        this.accountNumber = accountNumber;
        this.accountHolders = accountHolders;
        balance = 0.0;
    }

    /**
     * get the balance
     *
     * @return    the balance of the account
     */
    public double getBalance()
    {
        // put your code here
        return balance;
    }
    /**
     * Get the account number
     *
     * @return account number
     */
    public String getAccountNumber()
    {
        return accountNumber;
    }
    public ArrayList<Customer> getAccountHolders()
    {
        return accountHolders;
    }
    /**
     * Set the amount in the balance
     *
     * @param  balance
     */
    public void setBalance(double balance)
    {
        this.balance = balance;
    }
    /**
     * A method to add money to the balance
     *
     * @param  depositAmount
     */
    public void addToBalance(double depositAmount)
    {
        balance += depositAmount;
    }
    /**
     * Withdrawl monay from the account
     *
     * @param  withdrawAmount
     */
    public void withdrawFromBalance(double withdrawAmount)
    {
        if(withdrawAmount <= balance) {
            balance -= withdrawAmount;
        }
    }
}