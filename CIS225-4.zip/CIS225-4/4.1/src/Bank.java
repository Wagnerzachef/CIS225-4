import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
/**
 * Write a description of class Bank here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bank
{
    // instance variables - replace the example below with your own
    private ArrayList<Card> cards;
    private ArrayList<Customer> customers;
    private ArrayList<Account> accounts;


    /**
     * Constructor for objects of class Bank
     */
    public Bank()
    {
        // initialise instance variables
        customers = new ArrayList<>();
        accounts = new ArrayList<>();
        cards = new ArrayList<>();
    }
    /**
     * a method to create a customer
     */
    public void addCustomer()
    {
        String firstName, lastName;
        Scanner scan = new Scanner(System.in);
        System.out.println("\nPlease enter customer's first name:");
        firstName = scan.next();
        System.out.println("\nPlease enter customer's last name:");
        lastName = scan.next();
        addCustomer(firstName, lastName);
        System.out.println("\nCustomer created.");
        printCustomerInformation(customers.get(customers.size() - 1));
    }
    /**
     * a method to add a customer to the bank
     */
    private void addCustomer(String customerFirstName, String customerLastName)
    {
        String customerID = generateCustomerID();

        while(validCustomerID(customerID) != true)
        {
            customerID = generateCustomerID();
        }
        customers.add(new Customer(customerID, customerFirstName, customerLastName));
    }
    /**
     * a method to add all of a customers details to a card
     */
    public void addCard()
    {
        String customerID, pin;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the customer's ID: ");
        customerID  = scan.next();
        System.out.println("Please enter a security pin: ");
        pin = scan.next();
        for(Customer customer : customers) {
            if(customer.getCustomerID().equals(customerID)) {
                ArrayList<String> accountNumbers = new ArrayList<String>();
                for(Account account : accounts) {
                    for(Customer customer2 : account.getAccountHolders()) {
                        if(customer2.getCustomerID().equals(customerID)) {
                            accountNumbers.add(account.getAccountNumber());
                        }
                    }
                }
                addCard(customer, pin, accountNumbers);
                System.out.println("Card created.");
                printCardInfo(cards.get(cards.size() - 1));
            }
        }
    }
    /**
     * a method to add a customer to a card
     */
    private void addCard(Customer holder,String pin, ArrayList<String> accountNumbers)
    {
        String cardNumber = generateCardNumber();
        while(validCustomerID(cardNumber) != true) {
            cardNumber = generateCustomerID();
        }
        cards.add(new Card(cardNumber, pin, holder, accountNumbers));
    }
    /**
     * a method to get all of the bank accounts
     *
     * @return    all of the accounts in the bank
     */
    public ArrayList<Account> getAccounts()
    {
        // put your code here
        return  accounts;
    }
    /**
     * a method to add an account to a customers name
     */
    public void addAccount()
    {
        String accountType;
        boolean complete = false;
        ArrayList<String> holderIDs = new ArrayList<String>();
        ArrayList<Customer> holders = new ArrayList<Customer>();
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the customer's ID: ");
        holderIDs.add(scan.next());
        while(!complete)
        {
            String userResponse;
            System.out.println("Is there another account holder? (yes or no)");
            userResponse = scan.next();
            if(userResponse.equals("yes")) {
                System.out.println("Please enter the customer's ID: ");
                holderIDs.add(scan.next());
            }
            else if(userResponse.equals("no")) {
                complete = true;
            }
            else {
                System.out.println("\nThat is not valid input.");
            }
        }
        for(String holderID : holderIDs) {
            for(Customer holder : customers) {
                if(holder.getCustomerID().equals(holderID)) {
                    holders.add(holder);
                }
            }
        }
        addAccount(holders);
        System.out.println("Account created.");
        printAccountInformation(accounts.get(accounts.size() - 1));
    }
    /**
     * a method to get all of the customers of the bank
     *
     * @return all of the banks customers
     */
    public ArrayList<Customer> getCustomers()
    {
        return customers;
    }
    /**
     * method to add an account to the accounts array list
     *
     * @param  holders
     */
    private void addAccount(ArrayList<Customer> holders)
    {
        String accountNumber = generateAccountNumber();
        while(validAccountNumber(accountNumber) != true) {
            accountNumber = generateAccountNumber();
        }
        accounts.add(new Account(accountNumber, holders));
    }
    /**
     * a method to create a random customer ID
     */
    private String generateCustomerID()
    {
        int[] idnumbers = new int[5];
        String customerID;
        Random rand = new Random();

        idnumbers[0] = rand.nextInt(9);
        idnumbers[1] = rand.nextInt(9);
        idnumbers[2] = rand.nextInt(9);
        idnumbers[3] = rand.nextInt(9);
        idnumbers[4] = rand.nextInt(9);

        StringBuilder id = new StringBuilder();

        for(int i : idnumbers) {
            id.append(i);
        }
        customerID = id.toString();
        return customerID;
    }
    /**
     * a method to make random account numbers
     */
    private String generateAccountNumber()
    {
        int[] numb = new int[16];
        String accountNumber;
        Random rand = new Random();

        numb[0] = rand.nextInt(9);
        numb[1] = rand.nextInt(9);
        numb[2] = rand.nextInt(9);
        numb[3] = rand.nextInt(9);
        numb[4] = rand.nextInt(9);
        numb[5] = rand.nextInt(9);
        numb[6] = rand.nextInt(9);
        numb[7] = rand.nextInt(9);
        numb[8] = rand.nextInt(9);
        numb[9] = rand.nextInt(9);
        numb[10] = rand.nextInt(9);
        numb[11] = rand.nextInt(9);
        numb[12] = rand.nextInt(9);
        numb[13] = rand.nextInt(9);
        numb[14] = rand.nextInt(9);
        numb[15] = rand.nextInt(9);

        StringBuilder account = new StringBuilder();

        for(int i : numb) {
            account.append(i);
        }
        accountNumber = account.toString();
        return accountNumber;
    }
    /**
     * a method to get all of the cards associated to the bank
     *
     * @return all of the cards
     */
    public ArrayList<Card> getCards()
    {
        return cards;
    }
    /**
     * a method to create a card number
     */
    private String generateCardNumber()
    {
        int[] number = new int[16];
        String cardNumber;
        Random rand = new Random();

        number[0] = rand.nextInt(9);
        number[1] = rand.nextInt(9);
        number[2] = rand.nextInt(9);
        number[3] = rand.nextInt(9);
        number[4] = rand.nextInt(9);
        number[5] = rand.nextInt(9);
        number[6] = rand.nextInt(9);
        number[7] = rand.nextInt(9);
        number[8] = rand.nextInt(9);
        number[9] = rand.nextInt(9);
        number[10] = rand.nextInt(9);
        number[11] = rand.nextInt(9);
        number[12] = rand.nextInt(9);
        number[13] = rand.nextInt(9);
        number[14] = rand.nextInt(9);
        number[15] = rand.nextInt(9);

        StringBuilder card = new StringBuilder();

        for(int i : number) {
            card.append(i);
        }
        cardNumber = card.toString();
        return cardNumber;
    }
    /**
     * method to validate customer ID
     *
     * @param  customerID
     */
    private boolean validCustomerID(String customerID)
    {
        for(Customer customer : customers) {
            if(customer.getCustomerID() == customerID) {
                return false;
            }
        }
        return true;
    }
    /**
     * method to validate card number
     *
     * @param  cardNumber
     */
    private boolean validCardNumber(String cardNumber)
    {
        for(Card card : cards)
        {
            if(card.getCardNumber() == cardNumber)
            {
                return false;
            }
        }
        return true;
    }
    /**
     * method to validate account number
     *
     * @param accountNumber
     */
    private boolean validAccountNumber(String accountNumber)
    {
        for(Account account : accounts) {
            if(account.getAccountNumber() == accountNumber) {
                return false;
            }
        }
        return true;
    }
    private void printCustomerInformation(Customer customer)
    {
        System.out.print("Customer ID: " + customer.getCustomerID() + "Name: " + customer.getCustomerFirstName() + " " + customer.getCustomerLastName());
    }
    private void printCardInfo(Card card)
    {
        System.out.print("Card Holder: " + card.getHolder().getCustomerFirstName() + " " + card.getHolder().getCustomerLastName() + "Card Number: " + card.getCardNumber() + "Card PIN: " + card.getPin() + "Accounts Linked: " + card.getAccountNumbers().toString());
    }
    private void printAccountInformation(Account account)
    {
        System.out.print("Account Number: " + account.getAccountNumber() +"Balance: " + account.getBalance());
    }
}
