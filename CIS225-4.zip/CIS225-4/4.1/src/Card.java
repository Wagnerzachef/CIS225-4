import java.util.ArrayList;
/**
 * A class to make cards..
 *
 * @author Zach Wagner
 * @version 1
 */
public class Card
{
    // instance variables - replace the example below with your own
    private String cardNumber;
    private String pin;
    private ArrayList<String> accountNumbers;
    private Customer holder;

    /**
     * Constructor for objects of class Card
     */
    public Card(String cardNumber, String pin, Customer holder, ArrayList<String> accountNumbers)
    {
        // initialise instance variables
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.accountNumbers = accountNumbers;
        this.holder = holder;
    }

    /**
     * get the pin
     *
     * @return    the pin
     */
    public String getPin()
    {
        // put your code here
        return pin;
    }
    /**
     * get the card number
     *
     * @return the card number
     */
    public String getCardNumber()
    {
        return cardNumber;
    }
    /**
     * get the account holders
     *
     * @return the account numbers
     */
    public ArrayList<String> getAccountNumbers()
    {
        return accountNumbers;
    }
    /**
     * a method to set the pin
     *
     * @param  pin
     */
    public void setPin(String pin)
    {
        this.pin = pin;
    }
    /**
     * method to get the card holder
     *
     * @return the card holder
     */
    public Customer getHolder()
    {
        return holder;
    }
}
