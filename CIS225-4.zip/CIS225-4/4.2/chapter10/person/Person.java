
/**
 * Write a description of class Person here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Person
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Person
     */
    public Person()
    {
        // initialise instance variables
        x = 0;
        Person p1 = new Person();
        Person p2 = new Person();
        PhDStudent phd1 = new PhDStudent();
        Teacher t1 = new Teacher();
        Student s1 = new Student();
        p1 = s1;
        s1 = phd1;        
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
