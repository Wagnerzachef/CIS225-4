import java.util.ArrayList;
import java.util.Random;
/**
 * Class to create Player.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Player extends Person
{
    // instance variables - replace the example below with your own
    private String currentRoom;
    private ArrayList<Item> inventory;

    /**
     * Constructor for objects of class Player
     */
    public Player(String name, String startRoom)
    {
        super(name);
        currentRoom = startRoom;
        inventory = new ArrayList<>();
    }

    /**
     * a method to display the current room
     *
     * @return    the current room
     */
    public String getCurrentRoom()
    {
        // put your code here
        return currentRoom;
    }
    /**
     * A method to display the inventory
     *
     * @return the inventory of the player
     */
    public ArrayList<Item> getInventory()
    {
        return inventory;
    }
    /**
     * Adds an item to inventory
     *
     * @param  item to be added
     */
    public void addInventory(Item item)
    {
        inventory.add(item);
    }
    /**
     * method to change current room
     *
     * @param
     */
    public void setCurrentRoom(String currentRoom)
    {
        this.currentRoom = currentRoom;
    }
    /**
     * a method to print out all of the items in the players inventory
     */
    public void printInventory()
    {
        System.out.print("Inventory: ");
        for(int i = 0; i < inventory.size(); i++) {
            System.out.print(i +" - " + inventory.get(i).getItem());
        }
    }
}
