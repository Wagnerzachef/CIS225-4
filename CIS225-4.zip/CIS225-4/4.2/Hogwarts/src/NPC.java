import java.util.Random;
/**
 * Class to create NPC's.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class NPC extends Person
{
    // instance variables - replace the example below with your own
    private static String npcName;

    /**
     * Constructor for objects of class NPC
     */
    public NPC()
    {
        // initialise instance variables
        super(setNPCName());

    }

    /**
     * A method to set an npc's name at random. Names from a wizard name generator
     *
     * @return the name of the npc
     */
    public static String setNPCName()
    {
        // put your code here
        Random rand = new Random();
        int i = rand.nextInt(10);
        switch(i) {
            case 0:
                npcName = "Herman Grouse";
                break;
            case 1:
                npcName = "Larch Rook";
                break;
            case 2:
                npcName = "Ackley Locus";
                break;
            case 3:
                npcName = "Lutie Rook";
                break;
            case 4:
                npcName = "Rosemary Pegas";
                break;
            case 5:
                npcName = "Florrie Kettles";
                break;
            case 6:
                npcName = "Raine Sands";
                break;
            case 7:
                npcName = "Moor Doe";
                break;
            case 8:
                npcName = "Antoinette Wolfs";
                break;
            case 9:
                npcName = "Poppy Cycad";
                break;
        }
        return npcName;
    }
    /**
     * method to get the npc name only
     *
     * @return the name of the npc
     */
    public String getNPCName()
    {
        return npcName;
    }
}
