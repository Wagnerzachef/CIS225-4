import java.util.Random;
/**
 * A class to .
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Item
{
    // instance variables - replace the example below with your own
    private String item;
    private boolean held;

    /**
     * Constructor for objects of class Item
     */
    public Item()
    {
        // initialise instance variables
        setItem();
        held = false;
    }

    /**
     * Method to set a item randomly.
     */
    public void setItem()
    {
        // put your code here
        Random rand = new Random();
        int i = rand.nextInt(8);
        switch(i) {
            case 0:
                item = "Enchanted Coin";
                break;
            case 1:
                item = "Invisibility Cloak";
                break;
            case 2:
                item = "Mandrake Root";
                break;
            case 3:
                item = "Polyjuice Potion";
                break;
            case 4:
                item = "Bimbas 5000";
                break;
            case 5:
                item = "Eye of Newt";
                break;
            case 6:
                item = "Remembrall";
                break;
            case 7:
                item = "Mokeskin Pouch";
                break;
        }
    }
    /**
     * A method to get the item
     *
     * @return the item name
     */
    public String getItem()
    {
        return item;
    }
    /**
     * a method to set the item to held
     *
     * @param held
     */
    public void setHeld(boolean held)
    {
        this.held = held;
    }
    /**
     * method to return the held value
     *
     * @return if the item if held or not
     */
    public boolean getHeld()
    {
        return held;
    }
}
