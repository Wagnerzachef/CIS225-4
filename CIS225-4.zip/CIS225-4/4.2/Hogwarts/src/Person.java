/**
 * A class to store names of people.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Person
{
    // instance variables - replace the example below with your own
    public String name;

    /**
     * Constructor for objects of class Person
     */
    public Person(String name)
    {
        // initialise instance variables
        this.name = name;
    }
    /**
     * method to change the name of a person
     *
     * @param   name
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * method to return the name of a person
     *
     * @return    the name of the person
     */
    public String getName()
    {
        // put your code here
        return name;
    }
}

