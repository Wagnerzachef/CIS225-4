import java.util.Random;

/**
 * Class to create rooms.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Room
{
    // instance variables - replace the example below with your own
    private float roomNPCChance;
    private float roomItemChance;
    private String roomName;
    private String roomDesc;
    private String northRoom;
    private String southRoom;
    private String eastRoom;
    private String westRoom;
    private NPC npc;
    private Item item;

    /**
     * Constructor for objects of class Room
     */
    public Room(float roomNPCChance, float roomItemChance, String roomName, String roomDesc, String northRoom, String southRoom, String eastRoom, String westRoom)
    {
        // initialise instance variables
        this.roomNPCChance = roomNPCChance;
        this.roomItemChance = roomItemChance;
        this.roomName = roomName;
        this.roomDesc = roomDesc;
        this.northRoom = northRoom;
        this.southRoom = southRoom;
        this.eastRoom = eastRoom;
        this.westRoom = westRoom;
        setNPC();
        setItem();
    }
    /**
     * method to get the chances of an item being in a room
     *
     * @return the rooms item chance
     */
    public float getRoomItemChance()
    {
        return roomItemChance;
    }
    /**
     * method to get a rooms N{PC chance
     *
     *@return the rooms NPC chance
     */
    public float getRoomNPCChance()
    {
        return roomNPCChance;
    }
    /**
     * method to get the rooms name
     *
     * @return the rooms name
     */
    public String getRoomName()
    {
        return roomName;
    }
    /**
     * method to get the rooms description
     *
     * @return the rooms description
     */
    public String getRoomDesc()
    {
        return roomDesc;
    }
    /**
     * method to get the rooms north neighbor
     *
     * @return the rooms north neighbor
     */
    public String getNorthRoom()
    {
        return northRoom;
    }
    /**
     * method to get the rooms south neighbor
     *
     * @return the rooms south neighbor
     */
    public String getSouthRoom()
    {
        return southRoom;
    }
    /**
     * method to get the rooms east neighbor
     *
     * @return the rooms east neighbor
     */
    public String getEastRoom()
    {
        return eastRoom;
    }
    /**
     * method to get the rooms west neighbor
     *
     * @return the rooms west neighbor
     */
    public String getWestRoom()
    {
        return westRoom;
    }
    /**
     * method to get the rooms NPC if it has one
     *
     * @return the rooms NPC
     */
    public NPC getNPC()
    {
        return npc;
    }
    /**
     * method to get the rooms name
     *
     * @return the rooms name
     */
    public Item getItem()
    {
        return item;
    }
    /**
     * method to create a npc in a room at random
     */
    private void setNPC()
    {
        Random rand = new Random();
        float i = rand.nextFloat();
        if(i <= roomNPCChance) {
            npc = new NPC();
        }
    }
    /**
     * method to randomly generate a item in a room
     */
    private void setItem()
    {
        Random rand = new Random();
        float i = rand.nextFloat();
        if(i <= roomItemChance) {
            item = new Item();
        }
    }
}