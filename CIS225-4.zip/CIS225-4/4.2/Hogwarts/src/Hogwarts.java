import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.io.File;
/**
 * Write a description of class Hogwarts here.
 *
 * @author Zachary Wagner
 * @version 1
 */
public class Hogwarts
{
    // instance variables - replace the example below with your own
    private float randomRoomChance;
    private boolean gameOver;
    private File roomFile;
    private ArrayList<Room> rooms;
    private Player player;

    /**
     * Constructor for objects of class Hogwarts
     */
    public Hogwarts(String playerName) throws java.io.FileNotFoundException
    {
        // initialise instance variables
        randomRoomChance = .15f;
        roomFile = new File("roomsfile.csv");
        rooms = new ArrayList<>();
        player = new Player(playerName, "Great Hall");
        populateRooms();
    }

    /**
     * The method that runs the game
     */
    public void game()
    {
        // put your code here
        gameOver = false;
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to Hogwarts School of Witchcraft and Wizardry");
        System.out.println("If you need help with directions, type in the word 'help'.");
        while(!gameOver) {
            printCurrentRoomDesc();
            System.out.println("Please enter a command: ");
            String playerIpt = scan.nextLine();
            checkPlayerIPT(playerIpt);
        }
    }
    /**
     * a method to check and validate user input before running what the user asked
     *
     * @param
     */
    private void checkPlayerIPT(String playerInput)
    {
        String[] playerInputs = playerInput.split("\\s+");
        Room currentRoom = null;
        for(Room room : rooms) {
            if(room.getRoomName().equals(player.getCurrentRoom())) {
                currentRoom = room;
            }
        }
        switch (playerInputs[0].toUpperCase()) {
            case "HELP":
                System.out.println("The valid commands are: go, to go into a room; take, to add an item to your inventory; inventory, to check your inventory; and quit, to quit the game.");
                break;
            case "GO":
                if(playerInputs.length > 1) {
                    switch(playerInputs[1].toUpperCase()) {
                        case "NORTH":
                            if(currentRoom.getNorthRoom().equals("none")) {
                                System.out.println("There is nothing to the North.");
                            }
                            else {
                                setCurrentRoom(currentRoom.getNorthRoom());
                            }
                            break;
                        case "SOUTH":
                            if(currentRoom.getSouthRoom().equals("none")) {
                                System.out.println("There is nothing to the South.");
                            }
                            else {
                                setCurrentRoom(currentRoom.getSouthRoom());
                            }
                            break;
                        case "EAST":
                            if(currentRoom.getEastRoom().equals("none")) {
                                System.out.println("There is nothing to the East.");
                            }
                            else {
                                setCurrentRoom(currentRoom.getEastRoom());
                            }
                            break;
                        case "WEST":
                            if(currentRoom.getWestRoom().equals("none")) {
                                System.out.println("There is nothing to the West.");
                            }
                            else {
                                setCurrentRoom(currentRoom.getWestRoom());
                            }
                            break;
                        default:
                            System.out.println("That is not a valid direction to go.");
                            break;
                    }
                }
                else {
                    System.out.println("The default valid directions are north, south, east, and west.");
                }
                break;
            case "TAKE":
                if(currentRoom.getItem() != null && !currentRoom.getItem().getHeld()) {
                    String itemName;
                    StringBuilder builder = new StringBuilder();
                    for(int i = 1; i < playerInputs.length; i++) {
                        if(i > 1) {
                            builder.append(" ");
                        }
                        builder.append(playerInputs[i]);
                    }
                    itemName = builder.toString();
                    if(itemName.toUpperCase().equals(currentRoom.getItem().getItem().toUpperCase())) {
                        System.out.println(currentRoom.getItem().getItem() + " taken.");
                        currentRoom.getItem().setHeld(true);
                        player.addInventory(currentRoom.getItem());
                    }
                }
                else {
                    System.out.println("There is no such item to take.");
                }
                break;
            case "INVENTORY":
                player.printInventory();
                break;
            default:
                System.out.println("That is not a valid command.");
                break;
            case "QUIT":
                System.out.println("Thanks for playing...");
                gameOver = true;
                break;
        }
    }
    /**
     * method to change the current room
     */
    private void setCurrentRoom(String room)
    {
        Random rand = new Random();
        float f = rand.nextFloat();
        if(f <= randomRoomChance) {
            Random rand2 = new Random();
            int i = rand2.nextInt(rooms.size() -1);
            player.setCurrentRoom(rooms.get(i).getRoomName());
            System.out.println("Some sorcery has telepoted you to a different part of the castle!");
        }
        else {
            player.setCurrentRoom(room);
        }
    }
    /**
     * a method to print the details of the current room
     */
    private void printCurrentRoomDesc()
    {
        Room currentRoom = null;
        for(Room room : rooms)
        {
            if(room.getRoomName().equals(player.getCurrentRoom()))
            {
                currentRoom = room;
            }
        }
        System.out.println("You are in " + currentRoom.getRoomName() + ". " + currentRoom.getRoomDesc() + " ");
        if(currentRoom.getItem() != null && !currentRoom.getItem().getHeld())
        {
            System.out.println("There is a " + currentRoom.getItem().getItem() + " here. ");
        }
        if(currentRoom.getNPC() != null)
        {
            System.out.println(currentRoom.getNPC().getNPCName() + " is here. ");
        }
        if(!currentRoom.getNorthRoom().equals("none"))
        {
            System.out.println("The " + currentRoom.getNorthRoom() + " is North of here. ");
        }
        if(!currentRoom.getSouthRoom().equals("none"))
        {
            System.out.println("The " + currentRoom.getSouthRoom() + " is South of here. ");
        }
        if(!currentRoom.getEastRoom().equals("none"))
        {
            System.out.println("The " + currentRoom.getEastRoom() + " is East of here. ");
        }
        if(!currentRoom.getWestRoom().equals("none"))
        {
            System.out.println("The " + currentRoom.getWestRoom() + " is West of here. ");
        }
    }

    /**
     * method to create rooms using csv file
     */
    private void populateRooms() throws java.io.FileNotFoundException
    {
        ArrayList<String> lines = new ArrayList<String>();
        try {
            Scanner scan = new Scanner(roomFile);
            while(scan.hasNext()) {
                lines.add(scan.nextLine());
            }
        }
        catch(java.io.FileNotFoundException ex) {
            System.out.println("File not found.");
        }
        int i = 0;
        while( i < lines.size()) {
            String[] lines2 = lines.get(i).split(",");
            float roomOccupiedChance = Float.parseFloat(lines2[0]);
            float roomItemChance = Float.parseFloat(lines2[1]);
            String roomName = lines2[2];
            String roomDescription = lines2[3];
            String northRoom = lines2[4];
            String southRoom = lines2[5];
            String eastRoom = lines2[6];
            String westRoom = lines2[7];
            rooms.add(new Room(roomOccupiedChance, roomItemChance, roomName, roomDescription, northRoom, southRoom, eastRoom, westRoom));
            i++;
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        Hogwarts game = null;
        Scanner scan = new Scanner(System.in);
        String playerName = scan.nextLine();
        try {
            game = new Hogwarts(playerName);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        game.game();
    }
}
