import java.util.List;
import java.util.Random;

/**
 * Write a description of class TransporterRoom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TransporterRoom extends Room
{
    // instance variables - replace the example below with your own
    private List rooms;

    /**
     * Constructor for objects of class TransporterRoom
     */
    public TransporterRoom(String description)
    {
        // initialise instance variables
        super(description);
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void setRooms(List<Room> rooms)
    {
        // put your code here
        this.rooms = rooms;
    }
    public Room getExit() 
    {
        return findRandomRoom();
    }
    private Room findRandomRoom()
    {
        Random random = new Random();
        Room choice = rooms.get(random.nextInt(rooms.size()));
        return rooms.get(choice);
    }
}
